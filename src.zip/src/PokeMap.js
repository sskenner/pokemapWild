import React from 'react';
import {View, Text} from 'react-native';

class PokeMap extends React.Component{
    render(){
        return(
            <View>
                <Text>Poke Map</Text>
            </View>
        )
    }
}

export default PokeMap;